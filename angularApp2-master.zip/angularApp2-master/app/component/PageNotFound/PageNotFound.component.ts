import { Component } from '@angular/core';

@Component({
    selector:'page-not-found',
    template:'are you lost ?'
})

export class PageNotFoundComponent {}