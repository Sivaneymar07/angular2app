import { Component } from '@angular/core';

@Component({
    templateUrl: './app/component/home/home.component.html'
})

export class HomeComponent {}