import { Injectable } from "@angular/core"
import { Http, Response } from "@angular/http";
import { Observable, Subscription, Subject } from "rxjs/Rx";

@Injectable()
export class PrototypeService{
    prototypes;
    prototypeSubscription:Subscription;
    prototypeSubject=new Subject<any>();
    errorMessage='';
    currFileName="";
    prototype;
    constructor(private http:Http){}
    loadPrototypes(fileName){
        this.currFileName=fileName;
        //return this.http.get('./assets/data/prototypes/'+fileName+'.json')
        this.prototypeSubscription = this.http.get('./assets/data/prototypes/chatbot.json')
        .map(
            (response: Response) =>{
             return response.json();
            }
        )
        .subscribe(
          (response) => {
            this.prototypes=response.prototypes;
            //console.log(response.prototypes) 
            this.prototypeSubject.next(this.prototypes.slice())       
          },
          (error)=>{
            this.errorMessage=error;
            console.log("Error : "+error)
          }
        )
    }
    getPrototypes()  {             
       return this.prototypes.slice();
    }

     getPrototype(id){ 
        if(this.prototypes){
          return this.prototypes.find(prototype => prototype.id === id);
        }else{
          return null;
        }              
        /**for(var i=0; i<this.prototypes.length; i++){        
          console.log(this.prototypes[i].id);
          if(this.prototypes[i].id === id){
            return this.prototypes[i];
          }
        }
        return null;**/        
     }

    
    private handleError(errorResponse: Response) {  
        console.log(errorResponse.statusText);  
        return Observable.throw(errorResponse.json().error || "Server error");  
    } 
}