import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toybox',
  templateUrl: './toybox.component.html',
  styleUrls: ['./toybox.component.css']
})
export class ToyboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
