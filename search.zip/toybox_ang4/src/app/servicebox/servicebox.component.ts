import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicebox',
  templateUrl: './servicebox.component.html',
  styleUrls: ['./servicebox.component.css']
})
export class ServiceboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
