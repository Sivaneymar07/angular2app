import { Component, OnInit, OnDestroy } from '@angular/core';
import { PrototypeService } from '../../shared/prototype.service';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router } from "@angular/router";



@Component({
  selector: 'app-prototype-list',
  templateUrl: './prototype-list.component.html',
  styleUrls: ['./prototype-list.component.css']
})
export class PrototypeListComponent implements OnInit, OnDestroy {

  prototypes=[];
  errorMessage='';
  prototypeSubscription:Subscription;
  prototypeFileName="";
  chatBotClick = false;

  constructor(private prototypeService: PrototypeService, private route:ActivatedRoute, private router:Router) {
    this.route.params.subscribe( 
      (params) => {
        this.prototypeFileName=params['id'];
      });
   }

  ngOnInit() {    
    /**this.prototypeSubscription = this.prototypeService.getPrototypes(this.prototypeFileName).subscribe(
      (response) => {
        this.prototypes=response.prototypes;
        console.log(response.prototypes)        
      },
      (error)=>{
        this.errorMessage=error;
        console.log("Error : "+error)
      }
    )**/
    this.prototypeService.loadPrototypes(this.prototypeFileName);
    this.prototypeSubscription = this.prototypeService.prototypeSubject.subscribe(
      (prototypes) => {
          this.prototypes= prototypes;
          console.log(this.prototypes)
      }
    )
    
  }

  onPrototypeClick(prototypeId){
    this.router.navigate([prototypeId], {relativeTo:this.route})
  }

   ngOnDestroy(){
    this.prototypeSubscription.unsubscribe();
  }

  gotoPrototypeDetail(prototypeId){
    this.router.navigate([prototypeId], {relativeTo:this.route})
  }

}
