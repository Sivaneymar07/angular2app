import { async, ComponentFixture, TestBed, inject  } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule, Router, RouterOutlet  } from '@angular/router';   
import {  HttpModule,
  Response,
  ResponseOptions,
  XHRBackend
} from '@angular/http';
import { MockBackend } from '@angular/http/testing';


import { PrototypeListComponent } from './prototype-list.component';
import { PrototypeService } from '../../shared/prototype.service';



class MockRouter {
    navigate(url: string) { return url; }
}
class MockPrototypeListComponent {

}



describe('PrototypeListComponent', () => {
  let component: PrototypeListComponent;
  let fixture: ComponentFixture<PrototypeListComponent>;
  let prototypeService:PrototypeService;
  let spy;
  let de;
  let el;
  let compiled
  
  console.log("PrototypeListComponent")

  beforeEach(async() => {
    
    TestBed.configureTestingModule({
      declarations: [ PrototypeListComponent ], 
      imports: [ 
        RouterTestingModule.withRoutes([
          {
              path : ':id', component : MockPrototypeListComponent
          }
        ]),
        HttpModule,
        RouterModule
       ],    
       providers:[ 
         PrototypeService,         
         { provide: XHRBackend, useClass: MockBackend }
       ]
    })
    .compileComponents()
    // .compileComponents().then( () => {
    //     fixture = TestBed.createComponent(CategoryListComponent);
    //     component = fixture.componentInstance;
    // })

     fixture = TestBed.createComponent(PrototypeListComponent);
     component = fixture.componentInstance;

  });

  beforeEach(async() => {
    fixture.whenStable().then(() => {

        console.log("beforeEach 2")        
        prototypeService = fixture.debugElement.injector.get(PrototypeService);
        console.log("before detectChanges")
        //fixture.detectChanges();
        console.log("after detectChanges")
        
        compiled = fixture.debugElement.nativeElement;
        console.log("compiled")
        //fixture.detectChanges();

    })
  });

  it('should be created', () => {
    
    expect(component).toBeTruthy();
    
  });

  it('should return an Observable<Array<Category>>',
    inject([PrototypeService, XHRBackend], (prototypeService, mockBackend) => {

      
      const mockResponse = {
          data: [
                {
                    "id" : "p1",
                    "name" : "Enterprise Mobile1 ",
                    "categoryUrl" : "../../assets/images/label.png",
                    "app_icon":"assets/images/library_icons/kony_music_ retail_icon.png",
                    "category": "Mobile",
                    "domain" : "Insurance",
                    "uploadDate": "12/01/2017",
                    "rating": 3,
                    "ratingUrl":"../../assets/images/star3.png",   
                    "accronym": "EM1",
                    "popularity": 5,         
                    "title" : "Kony SounDigital",
                    "industry" :"P&R",
                    "shortDescription" : "One stop e-store store for all your music needs",
                    "description" : "Kony SounDigital brings to you the complete music store at great prices. This application lets the user explore the world of music accessories, compare them and buy them without a hassle. This application ensures a smooth shopping experience with spectrum of special offers exclusively for the user.",
                    "thumbnail_url" :"",
                    "playstore_url" :"",
                    "ios_url" : "",
                    "platform":"",
                    "screenshots": [
                                "../../assets/images/kony music retail/Screenshot_2017-08-29-11-59-20-333_com.kony.FunctionPreviewApp.png",
                                "../../assets/images/kony music retail/Screenshot_2017-08-29-11-59-32-071_com.kony.FunctionPreviewApp.png",
                                "../../assets/images/kony music retail/Screenshot_2017-08-29-11-59-57-687_com.kony.FunctionPreviewApp.png",
                                "../../assets/images/kony music retail/Screenshot_2017-08-29-12-00-16-925_com.kony.FunctionPreviewApp.png",
                                "../../assets/images/kony music retail/Screenshot_2017-08-29-12-00-24-400_com.kony.FunctionPreviewApp.png",
                                "../../assets/images/kony music retail/Screenshot_2017-08-29-12-00-31-254_com.kony.FunctionPreviewApp.png"
                            ]
                }
          ]
        };



      mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

      prototypeService.prototypeSubject.subscribe((prototype) => { 
        console.log("@prototype")       
        console.log("@prototype"+prototype.data[0].id)
        expect(prototype.data.length).toBe(1);
        expect(prototype.data[0].id).toEqual('p1');        
        expect(prototype.data[0].name).toEqual('Enterprise Mobile1 ');
        expect(prototype.data[0].categoryUrl).toEqual('../../assets/images/label.png');
        expect(prototype.data[0].app_icon).toEqual('assets/images/library_icons/kony_music_ retail_icon.png');
        expect(prototype.data[0].category).toEqual('Mobile');
        expect(prototype.data[0].domain).toEqual('Insurance');
        expect(prototype.data[0].uploadDate).toEqual('12/01/2017');
        expect(prototype.data[0].rating).toEqual('3');
        expect(prototype.data[0].ratingUrl).toEqual('../../assets/images/star3.png');
        expect(prototype.data[0].accronym).toEqual('EM1');
        expect(prototype.data[0].popularity).toEqual('5');
        expect(prototype.data[0].title).toEqual('Kony SounDigital');
        expect(prototype.data[0].industry).toEqual('P&R');
        expect(prototype.data[0].shortDescription).toEqual('One stop e-store store for all your music needs');
        expect(prototype.data[0].description).toEqual('Kony SounDigital brings to you the complete music store at great prices. This application lets the user explore the world of music accessories, compare them and buy them without a hassle. This application ensures a smooth shopping experience with spectrum of special offers exclusively for the user.');
        expect(prototype.data[0].thumbnail_url).toEqual('');
        expect(prototype.data[0].playstore_url).toEqual('');
        expect(prototype.data[0].ios_url).toEqual('');
        expect(prototype.data[0].platform).toEqual('');
        expect(prototype.data[0].screenshots).toEqual('');
        
       
      });

  }));

  
//   it('should call Router.naigate with the ID ',inject([Router], (router: Router) =>{


//     const spy = spyOn(router, 'navigate');
//     component.onPrototypeClick('/p1');

//     const navArgs = spy.calls.first().args[0];
//     console.log("---"+navArgs)
//     console.log("---"+component.prototypes.length)
//     //const id = component.prototypes[0].id;

//     expect(navArgs).toEqual('/p1', 'should nav to Prototype List');
   
//   }))


});
