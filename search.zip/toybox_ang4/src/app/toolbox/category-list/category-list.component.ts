import { Component, OnInit, OnDestroy } from '@angular/core';
import { CategoryService } from '../../shared/category.service';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router } from "@angular/router";


@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit , OnDestroy {

  categories=[];
  errorMessage='';
  categorySubscription:Subscription;
 
  constructor(private categoryService: CategoryService, private route:ActivatedRoute, private router:Router) { }

  ngOnInit() {
    this.categorySubscription = this.categoryService.getCategories().subscribe(
      (response) => {
        this.categories=response.category;        
      },
      (error)=>{
        this.errorMessage=error;
        console.log("Error : "+error)
      }
    )
  }
  

  onCategoryClick(id){
    this.router.navigate([id], {relativeTo:this.route})
  }

  ngOnDestroy(){
    this.categorySubscription.unsubscribe();
  }
}
