import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prototype-item',
  templateUrl: './prototype-item.component.html',
  styleUrls: ['./prototype-item.component.css']
})
export class PrototypeItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
