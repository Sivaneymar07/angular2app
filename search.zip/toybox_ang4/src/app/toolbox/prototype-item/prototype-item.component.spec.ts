// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PrototypeItemComponent } from './prototype-item.component';

// describe('PrototypeItemComponent', () => {
//   let component: PrototypeItemComponent;
//   let fixture: ComponentFixture<PrototypeItemComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PrototypeItemComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PrototypeItemComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
